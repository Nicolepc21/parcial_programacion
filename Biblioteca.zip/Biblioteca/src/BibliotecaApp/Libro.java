package biblioteca;

public class Libro extends Material {
    private String autor;
    private int paginas;

    public Libro(String id, String titulo, String autor, int paginas) {
        super(id, titulo, "Libro");
        this.autor = autor;
        this.paginas = paginas;
    }

    public String getAutor() { return autor; }
    public int getPaginas() { return paginas; }

    //Polimorfismo con material
    @Override
    public String toString() {
        return super.toString() + " - " + autor + " - " + paginas + " pág.";
    }
}
