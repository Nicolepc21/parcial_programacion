package biblioteca;

public class Material {
    protected String id;         
    protected String titulo;
    protected String tipo;       
    protected boolean prestado;  

    // Constructor
    public Material(String id, String titulo, String tipo) {
        this.id = id;
        this.titulo = titulo;
        this.tipo = tipo;
        this.prestado = false;
    }

    // Getters y setters
    public String getId() { return id; }
    public String getTitulo() { return titulo; }
    public String getTipo() { return tipo; }
    public boolean isPrestado() { return prestado; }

    public void setPrestado(boolean prestado) { this.prestado = prestado; }

    //Polimorfismo con libro
    @Override
    public String toString() {
        return id + " - " + titulo + " (" + tipo + ") " + (prestado ? "[Prestado]" : "[Disponible]");
    }
}