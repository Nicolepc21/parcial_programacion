package biblioteca;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;

public class MainFrame extends JFrame {
    private Biblioteca biblioteca;
    private JTextArea salidaArea;

    public MainFrame() {
        biblioteca = new Biblioteca();
        initUI();
    }

    private void initUI() {
        setTitle("Menú Biblioteca - UNIMINUTO");
        setSize(700, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout(10,10));
        getContentPane().add(panel);

        JLabel titulo = new JLabel("Menú Biblioteca", SwingConstants.CENTER);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 20));
        panel.add(titulo, BorderLayout.NORTH);

        salidaArea = new JTextArea();
        salidaArea.setEditable(false);
        JScrollPane scroll = new JScrollPane(salidaArea);
        panel.add(scroll, BorderLayout.CENTER);

        JPanel botones = new JPanel(new GridLayout(1,5,5,5));
        JButton btnInventario = new JButton("1 - Inventario");
        JButton btnPrestamo = new JButton("2 - Préstamo");
        JButton btnDevolucion = new JButton("3 - Devolución");
        JButton btnMultas = new JButton("4 - Multas");
        JButton btnSalir = new JButton("5 - Salir");

        botones.add(btnInventario);
        botones.add(btnPrestamo);
        botones.add(btnDevolucion);
        botones.add(btnMultas);
        botones.add(btnSalir);
        panel.add(botones, BorderLayout.SOUTH);

        btnInventario.addActionListener(e -> mostrarInventario());
        btnPrestamo.addActionListener(e -> accionPrestamo());
        btnDevolucion.addActionListener(e -> accionDevolucion());
        btnMultas.addActionListener(e -> accionMultas());
        btnSalir.addActionListener(e -> System.exit(0));

        mostrarInventario();
    }

    // Mostrar inventario
    private void mostrarInventario() {
        StringBuilder sb = new StringBuilder("=== Inventario ===\n");
        for (Material m : biblioteca.getInventario()) {
            sb.append(m.toString()).append("\n");
        }
        salidaArea.setText(sb.toString());
    }

    // préstamo
    private void accionPrestamo() {
        String id = JOptionPane.showInputDialog(this, "Ingrese ID del material a prestar (ej: L001):");
        if (id == null || id.trim().isEmpty()) return;

        String usuario = JOptionPane.showInputDialog(this, "Nombre del usuario:");
        if (usuario == null || usuario.trim().isEmpty()) return;
        JOptionPane.showMessageDialog(this, "Ahora ingrese la fecha del préstamo (día, mes, año)");
        String diaStr = JOptionPane.showInputDialog(this, "Día (ej: 1):");
        String mesStr = JOptionPane.showInputDialog(this, "Mes (ej: 10):");
        String anioStr = JOptionPane.showInputDialog(this, "Año (ej: 2025):");

        int dia = 1, mes = 1, anio = 2025;
        try {
            dia >= 31;
            mes >= 12;
          catch (Excepcion e) {
                JOptionPane.showMessageDialog(this, "Error en la fecha ingresada");
                LocalDate hoy = LocalDate.now();
                dia = hoy.getDayOfMonth();
                mes = hoy.getMonthValue();
                anio = hoy.getYear();
                }
            dia = Integer.parseInt(diaStr);
            mes = Integer.parseInt(mesStr);
            anio = Integer.parseInt(anioStr);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error en la fecha. Se usará la fecha actual.");
            LocalDate hoy = LocalDate.now();
            dia = hoy.getDayOfMonth();
            mes = hoy.getMonthValue();
            anio = hoy.getYear();
        }

        LocalDate fechaPrestamo = LocalDate.of(anio, mes, dia);

        String diasStr = JOptionPane.showInputDialog(this, "Días permitidos (ej: 7):");
        int dias = 7;
        try { dias = Integer.parseInt(diasStr); } catch (Exception ex) { dias = 7; }

        String msg = biblioteca.prestar(id.trim(), usuario.trim(), fechaPrestamo, dias);
        JOptionPane.showMessageDialog(this, msg);
        mostrarInventario();
    }

    // Devolución 
    private void accionDevolucion() {
        String id = JOptionPane.showInputDialog(this, "Ingrese ID del material a devolver (ej: L001):");
        if (id == null || id.trim().isEmpty()) return;

        JOptionPane.showMessageDialog(this, "Ahora ingrese la fecha de devolución (día, mes, año)");
        String diaStr = JOptionPane.showInputDialog(this, "Día (ej: 1):");
        String mesStr = JOptionPane.showInputDialog(this, "Mes (ej: 10):");
        String anioStr = JOptionPane.showInputDialog(this, "Año (ej: 2025):");

        int dia = 1, mes = 1, anio = 2025;
        try {
            dia = Integer.parseInt(diaStr);
            mes = Integer.parseInt(mesStr);
            anio = Integer.parseInt(anioStr);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error en la fecha. Se usará la fecha actual.");
            LocalDate hoy = LocalDate.now();
            dia = hoy.getDayOfMonth();
            mes = hoy.getMonthValue();
            anio = hoy.getYear();
        }

        LocalDate fechaDevolucion = LocalDate.of(anio, mes, dia);

        String respuesta = biblioteca.devolver(id.trim(), fechaDevolucion);
        JOptionPane.showMessageDialog(this, respuesta);
        mostrarInventario();
    }

    // Consultar multas 
    private void accionMultas() {
        String id = JOptionPane.showInputDialog(this, "Ingrese ID del material para consultar multa (ej: L001):");
        if (id == null || id.trim().isEmpty()) return;
        String res = biblioteca.consultarMulta(id.trim(), 2000);
        JOptionPane.showMessageDialog(this, res);
    }

    // Método main 
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainFrame mf = new MainFrame();
            mf.setVisible(true);
        });
    }
}
