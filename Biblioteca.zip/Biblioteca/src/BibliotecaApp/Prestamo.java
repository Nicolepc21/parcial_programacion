package biblioteca;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Prestamo {
    private Material material;
    private String nombreUsuario;
    private LocalDate fechaPrestamo;
    // null si no se ha devuelto
    private LocalDate fechaDevolucion; 
    private int diasPermitidos;

    public Prestamo(Material material, String nombreUsuario, LocalDate fechaPrestamo, int diasPermitidos) {
        this.material = material;
        this.nombreUsuario = nombreUsuario;
        this.fechaPrestamo = fechaPrestamo;
        this.diasPermitidos = diasPermitidos;
        this.fechaDevolucion = null;
    }

    public Material getMaterial() { return material; }
    public String getNombreUsuario() { return nombreUsuario; }
    public LocalDate getFechaPrestamo() { return fechaPrestamo; }
    public LocalDate getFechaDevolucion() { return fechaDevolucion; }
    public void setFechaDevolucion(LocalDate fecha) { this.fechaDevolucion = fecha; }

    // Calcula días de retraso
    public long diasRetraso() {
        LocalDate fin = (fechaDevolucion == null ? LocalDate.now() : fechaDevolucion);
        long dias = ChronoUnit.DAYS.between(fechaPrestamo, fin);
        long retraso = dias - diasPermitidos;
        return retraso > 0 ? retraso : 0;
    }

    // Calcula multa
    public double calcularMulta(double tarifaPorDia) {
        return diasRetraso() * tarifaPorDia;
    }

    @Override
    public String toString() {
        return material.getId() + " - " + material.getTitulo() + " | Usuario: " + nombreUsuario +
               " | Prestado: " + fechaPrestamo +
               (fechaDevolucion == null ? " | (No devuelto)" : " | Dev: " + fechaDevolucion);
    }
}
