package biblioteca;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Biblioteca {
    private List<Material> inventario;
    private List<Prestamo> prestamos;

    public Biblioteca() {
        inventario = new ArrayList<>();
        prestamos = new ArrayList<>();
        cargarEjemplo();
    }

    public void agregarMaterial(Material m) {
        inventario.add(m);
    }

    public List<Material> getInventario() { return inventario; }
    public List<Prestamo> getPrestamos() { return prestamos; }

    public Optional<Material> buscarPorId(String id) {
        return inventario.stream().filter(m -> m.getId().equalsIgnoreCase(id)).findFirst();
    }

    public String prestar(String idMaterial, String nombreUsuario, LocalDate fechaPrestamo, int diasPermitidos) {
        Optional<Material> opt = buscarPorId(idMaterial);
        if (!opt.isPresent()) return "Material no encontrado.";
        Material m = opt.get();
        if (m.isPrestado()) return "El material ya está prestado.";
        m.setPrestado(true);
        Prestamo p = new Prestamo(m, nombreUsuario, fechaPrestamo, diasPermitidos);
        prestamos.add(p);
        return "Préstamo registrado correctamente.";
    }

    public String devolver(String idMaterial, LocalDate fechaDevolucion) {
        Optional<Prestamo> opt = prestamos.stream()
                .filter(p -> p.getMaterial().getId().equalsIgnoreCase(idMaterial) && p.getFechaDevolucion() == null)
                .findFirst();
        if (!opt.isPresent()) return "No existe préstamo activo para ese material.";
        Prestamo p = opt.get();
        p.setFechaDevolucion(fechaDevolucion);
        p.getMaterial().setPrestado(false);
        return "Devolución registrada. Multa: " + p.calcularMulta(2000) + " (COP)";
    }

    public String consultarMulta(String idMaterial, double tarifaPorDia) {
        Optional<Prestamo> opt = prestamos.stream()
                .filter(p -> p.getMaterial().getId().equalsIgnoreCase(idMaterial))
                .reduce((first, second) -> second); 
        if (!opt.isPresent()) return "No hay registro de préstamo para ese material.";
        Prestamo p = opt.get();
        double multa = p.calcularMulta(tarifaPorDia);
        return "Multa actual: " + multa + " (COP). Días de retraso: " + p.diasRetraso();
    }

    // Base de datos 
    private void cargarEjemplo() {
        // Libros sobre programación y tecnología
        agregarMaterial(new Libro("L001", "Programación en Java", "Juan Pérez", 450));
        agregarMaterial(new Libro("L002", "Estructuras de Datos", "Ana Gómez", 380));
        agregarMaterial(new Libro("L003", "Bases de Datos", "Carlos Ruiz", 320));
        agregarMaterial(new Libro("L004", "Desarrollo Web con HTML y CSS", "Laura Rojas", 290));
        agregarMaterial(new Libro("L005", "Inteligencia Artificial Básica", "Miguel Torres", 510));
        agregarMaterial(new Libro("L006", "Redes de Computadores", "Paula Martínez", 410));
        agregarMaterial(new Libro("L007", "Python para Principiantes", "Andrés Díaz", 350));
        agregarMaterial(new Libro("L008", "Sistemas Operativos", "Fernando Gutiérrez", 400));
        agregarMaterial(new Libro("L009", "Ciberseguridad para Todos", "Juliana Herrera", 420));
        agregarMaterial(new Libro("L010", "Desarrollo de Apps Móviles", "Camilo García", 360));

        // Revistas tecnológicas
        agregarMaterial(new Material("R001", "Revista Tecnología Hoy", "Revista"));
        agregarMaterial(new Material("R002", "Innovación Digital", "Revista"));
        agregarMaterial(new Material("R003", "Computación y Futuro", "Revista"));
        agregarMaterial(new Material("R004", "Revista Ciencia y Software", "Revista"));
        agregarMaterial(new Material("R005", "Tendencias en IA", "Revista"));

        // Tesis académicas
        agregarMaterial(new Material("T001", "Tesis: Machine Learning en Agricultura", "Tesis"));
        agregarMaterial(new Material("T002", "Tesis: Seguridad Informática en Redes", "Tesis"));
        agregarMaterial(new Material("T003", "Tesis: Big Data para Salud Pública", "Tesis"));
        agregarMaterial(new Material("T004", "Tesis: Blockchain en Finanzas", "Tesis"));
        agregarMaterial(new Material("T005", "Tesis: Realidad Virtual Educativa", "Tesis"));
    }
}
